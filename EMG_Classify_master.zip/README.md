# EMG_Final_version_2020
Publish Submited : EMG Signal Classsification:a review(ali abedi,....)
Emg classification master.
this package have compelement and because of depend Articles securities, did not publish compelete.
Package is Include:
1-Preprocessing
2-Feature Extraction(time-domain)
3-Data Classification(socre,error,confusion-matrix)
for more information please contact:aliabedi.tums@gmail.com
